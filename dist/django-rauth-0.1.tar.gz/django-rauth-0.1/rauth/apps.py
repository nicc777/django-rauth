from django.apps import AppConfig


class RauthConfig(AppConfig):
    name = 'rauth'
